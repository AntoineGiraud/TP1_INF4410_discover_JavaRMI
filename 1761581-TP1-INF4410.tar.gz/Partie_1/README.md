# TP1.1 INF4410 1761581

D'après l'énoncé du TP : rien n'a changé de ce côté là.

1. Compilez avec la commande ant..
2. Démarrez le registre RMI avec la commande rmiregistry à partir du dossier bin de votre projet. Ajoutez un & pour le détacher de la console.
3. Démarrez le serveur avec le script server (./server ou bash server).
4. Lancez le client avec le script client. Le script passe les arguments qu'il reçoit au programme
Java, donc vous pouvez le réutiliser pour les commandes de la partie 2. Si un argument est
donné au client, il l'utilise comme nom d'hôte pour tenter de faire un appel RMI à distance,
donc vous pouvez faire ./client 132.207.72.58.